/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/data/assameseScheme.ts":
/*!************************************!*\
  !*** ./src/data/assameseScheme.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   assameseScheme: () => (/* binding */ assameseScheme)
/* harmony export */ });
var assameseScheme = {
    consonants: {
        ক: ["k", "K"],
        খ: ["kh", "kH", "Kh", "KH"],
        গ: ["g", "G"],
        ঘ: ["gh", "gH", "Gh", "GH"],
        ঙ: ["ng", "Ng", "NG", "nG"],
        চ: ["s", "c"],
        ছ: ["S", "ss", "Ss", "SS", "cc", "Cc", "CC"],
        জ: ["j", "z"],
        ঝ: ["jh", "jH", "Jh", "JH"],
        ঞ: ["yy", "Y"],
        ট: ["T"],
        ঠ: ["Th"],
        ড: ["D"],
        ঢ: ["Dh"],
        ণ: ["N"],
        ত: ["t"],
        থ: ["th"],
        দ: ["d"],
        ধ: ["dh"],
        ন: ["n"],
        প: ["p", "P"],
        ফ: ["f", "F", "ph", "pH", "Ph", "PH"],
        ব: ["b", "B"],
        ভ: ["v", "V", "bh", "bH", "Bh", "BH"],
        ম: ["m", "M"],
        য: ["J", "jj", "JJ", "Jj", "Z", "zz", "ZZ", "Zz"],
        ৰ: ["r"],
        ল: ["l", "L"],
        ৱ: ["w", "W"],
        স: ["x", "X"],
        শ: ["xx", "Xx", "xX", "XX"],
        ষ: ["xxx", "XxX", "xXX", "XXX", "xxX", "xXx", "Xxx"],
        হ: ["h", "H"],
        ড়: ["rr", "R", "RR", "rR", "Rr"],
        ঢ়: ["rh", "Rh", "rH", "RH"],
        য়: ["y"],
        ক্ষ: ["khyy"],
    },
    vowels: {
        অ: ["o"],
        আ: ["a"],
        ই: ["i"],
        ঈ: ["ii"],
        উ: ["u"],
        ঊ: ["uu", "U"],
        ঋ: ["riii"],
        এ: ["e"],
        ঐ: ["oi"],
        ও: ["uuu", "oo", "O"],
        ঔ: ["ou"],
    },
    vowelMarks: {
        "": ["o"],
        "া": ["a"],
        "ি": ["i"],
        "ী": ["ii"],
        "ু": ["u"],
        "ূ": ["uu", "U"],
        "ৃ": ["riii"],
        "ে": ["e"],
        "ৈ": ["oi"],
        "ো": ["uuu", "oo", "O"],
        "ৌ": ["ou"],
    },
    specialChar: {
        "ং": ["ngg", "Ngg", "nGg", "NGg", "ngG", "NgG", "nGG", "NGG"],
        "ঃ": ["hh", "HH", "hH", "Hh"],
        "ঁ": ["*"],
        "ৎ": ["t", "T"],
        "।": ["|"],
    },
    digits: {
        "০": ["0"],
        "১": ["1"],
        "২": ["2"],
        "৩": ["3"],
        "৪": ["4"],
        "৫": ["5"],
        "৬": ["6"],
        "৭": ["7"],
        "৮": ["8"],
        "৯": ["9"],
    },
    exceptions: {
        specialCombinations: {
            "gyy": "জ্ঞ",
            "jyy": "হ্য",
            "khm": "ক্ষ্ম",
        },
        joinedConsonantsBefore: {
            "চ": "স",
        },
        joinedConsonantsAfter: {
            "w": "ব",
            "y": "য",
        },
        explicitHolonto: "্",
    },
};


/***/ }),

/***/ "./src/utils/transliteration.ts":
/*!**************************************!*\
  !*** ./src/utils/transliteration.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   transliterate: () => (/* binding */ transliterate)
/* harmony export */ });
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
function transliterate(input, scheme) {
    var output = "";
    var i = 0;
    var previousCharWasConsonant = false;
    var skipNextCombination = false;
    var inBackticks = false;
    while (i < input.length) {
        var result = processNextCharacter(input, i, scheme, previousCharWasConsonant, skipNextCombination, inBackticks);
        output += result.output;
        i = result.newIndex;
        previousCharWasConsonant = result.previousCharWasConsonant;
        skipNextCombination = result.skipNextCombination;
        inBackticks = result.inBackticks;
    }
    return output;
}
function processNextCharacter(input, index, scheme, previousCharWasConsonant, skipNextCombination, inBackticks) {
    var backtickResult = handleBackticks(input, index);
    if (backtickResult) {
        return __assign(__assign({}, backtickResult), { inBackticks: backtickResult.output === "" ? !inBackticks : inBackticks });
    }
    if (inBackticks) {
        return {
            output: input[index],
            newIndex: index + 1,
            previousCharWasConsonant: previousCharWasConsonant,
            skipNextCombination: skipNextCombination,
            inBackticks: inBackticks,
        };
    }
    if (input[index] === ".") {
        if (input[index + 1] === ".") {
            return {
                output: scheme.exceptions.explicitHolonto,
                newIndex: index + 2,
                previousCharWasConsonant: false,
                skipNextCombination: false,
                inBackticks: inBackticks,
            };
        }
        return {
            output: "",
            newIndex: index + 1,
            previousCharWasConsonant: previousCharWasConsonant,
            skipNextCombination: true,
            inBackticks: inBackticks,
        };
    }
    for (var _i = 0, _a = Object.entries(scheme.exceptions.specialCombinations); _i < _a.length; _i++) {
        var _b = _a[_i], combo = _b[0], result = _b[1];
        if (input.startsWith(combo, index)) {
            return {
                output: result,
                newIndex: index + combo.length,
                previousCharWasConsonant: true,
                skipNextCombination: false,
                inBackticks: false,
            };
        }
    }
    return handleRegularTransliteration(input, index, scheme, previousCharWasConsonant, skipNextCombination);
}
function handleBackticks(input, index) {
    if (input[index] === "\\" &&
        index + 1 < input.length &&
        input[index + 1] === "`") {
        return {
            output: "`",
            newIndex: index + 2,
            previousCharWasConsonant: false,
            skipNextCombination: false,
            inBackticks: false,
        };
    }
    if (input[index] === "`") {
        return {
            output: "",
            newIndex: index + 1,
            previousCharWasConsonant: false,
            skipNextCombination: false,
            inBackticks: false,
        };
    }
    return null;
}
function handleRegularTransliteration(input, index, scheme, previousCharWasConsonant, skipNextCombination) {
    var _a = findLongestMatch(input, index, scheme, skipNextCombination), longestMatch = _a.longestMatch, matchedChar = _a.matchedChar, matchedCategory = _a.matchedCategory;
    if (longestMatch) {
        return processMatch(input, index, matchedChar, matchedCategory, scheme, previousCharWasConsonant, skipNextCombination, longestMatch);
    }
    return {
        output: input[index],
        newIndex: index + 1,
        previousCharWasConsonant: false,
        skipNextCombination: false,
        inBackticks: false,
    };
}
function findLongestMatch(input, index, scheme, skipNextCombination) {
    var longestMatch = "";
    var matchedChar = "";
    var matchedCategory = null;
    for (var _i = 0, _a = [
        "consonants",
        "vowels",
        "vowelMarks",
        "specialChar",
        "digits",
    ]; _i < _a.length; _i++) {
        var category = _a[_i];
        for (var _b = 0, _c = Object.entries(scheme[category]); _b < _c.length; _b++) {
            var _d = _c[_b], assamese = _d[0], romanizations = _d[1];
            for (var _e = 0, romanizations_1 = romanizations; _e < romanizations_1.length; _e++) {
                var romanization = romanizations_1[_e];
                if (input.startsWith(romanization, index) &&
                    romanization.length > longestMatch.length &&
                    (!skipNextCombination || romanization.length === 1)) {
                    longestMatch = romanization;
                    matchedChar = assamese;
                    matchedCategory = category;
                }
            }
        }
    }
    return { longestMatch: longestMatch, matchedChar: matchedChar, matchedCategory: matchedCategory };
}
function processMatch(input, index, matchedChar, matchedCategory, scheme, previousCharWasConsonant, skipNextCombination, longestMatch) {
    var output = "";
    var newPreviousCharWasConsonant = false;
    if (matchedCategory === "consonants") {
        if (previousCharWasConsonant && !skipNextCombination) {
            output += scheme.exceptions.explicitHolonto;
        }
        var nextChar = findNextConsonant(input, index + longestMatch.length, scheme);
        if (nextChar && scheme.exceptions.joinedConsonantsBefore[matchedChar]) {
            output += scheme.exceptions.joinedConsonantsBefore[matchedChar];
        }
        else {
            output += matchedChar;
        }
        newPreviousCharWasConsonant = true;
    }
    else if (matchedCategory === "vowels") {
        if (previousCharWasConsonant && !skipNextCombination) {
            var vowelMarker = Object.entries(scheme.vowelMarks).find(
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
            function (_a) {
                var _ = _a[0], markers = _a[1];
                return markers.includes(scheme.vowels[matchedChar][0]);
            });
            if (vowelMarker) {
                output += vowelMarker[0];
            }
            else {
                output += matchedChar;
            }
        }
        else {
            output += matchedChar;
        }
    }
    else {
        output += matchedChar;
    }
    if (previousCharWasConsonant &&
        scheme.exceptions.joinedConsonantsAfter[longestMatch]) {
        output =
            scheme.exceptions.explicitHolonto +
                scheme.exceptions.joinedConsonantsAfter[longestMatch];
        newPreviousCharWasConsonant = true;
    }
    return {
        output: output,
        newIndex: index + longestMatch.length,
        previousCharWasConsonant: newPreviousCharWasConsonant,
        skipNextCombination: false,
        inBackticks: false,
    };
}
function findNextConsonant(input, startIndex, scheme) {
    for (var i = startIndex; i < input.length; i++) {
        var _a = findLongestMatch(input, i, scheme, false), matchedChar = _a.matchedChar, matchedCategory = _a.matchedCategory;
        if (matchedCategory === "consonants") {
            return matchedChar;
        }
        if (matchedCategory !== null) {
            break;
        }
    }
    return null;
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!**********************************!*\
  !*** ./extension-src/content.js ***!
  \**********************************/
/* eslint-disable @typescript-eslint/no-require-imports */
const { transliterate } = __webpack_require__(/*! @/utils/transliteration */ "./src/utils/transliteration.ts");
const { assameseScheme } = __webpack_require__(/*! @/data/assameseScheme */ "./src/data/assameseScheme.ts");

let isEnabled = true;

// eslint-disable-next-line @typescript-eslint/no-unused-vars
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "stateChanged") {
    isEnabled = request.isEnabled;
  }
});

function handleInput(event) {
  if (!isEnabled) return;

  const target = event.target;
  if (target.tagName !== "INPUT" && target.tagName !== "TEXTAREA") return;

  const cursorPosition = target.selectionStart;
  const input = target.value;
  
  const output = transliterate(input, assameseScheme);

  if (output !== input) {
    target.value = output;
    
    const newPosition = cursorPosition + (output.length - input.length);
    target.setSelectionRange(newPosition, newPosition);
  }
}

document.addEventListener("input", handleInput);

chrome.runtime.sendMessage({ action: "getState" }, (response) => {
  isEnabled = response.isEnabled;
});
})();

/******/ })()
;
//# sourceMappingURL=content.js.map